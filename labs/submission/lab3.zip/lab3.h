/*
 BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE STRICTLY ADHERED TO THE
 TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY WITH RESPECT TO
 THIS ASSIGNMENT.
 */

/* Author: Yifan Yao.740 */
char *readtitles(void);
int getfavorites(unsigned int numOfFavBooks, char ***favBooks);
int savedata(char fileName[255], unsigned int numOfBooks, char **bookList, unsigned int numOfFavBooks, char ***favBooks);
